"""Settings for configuration."""


from pydantic import BaseModel, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class CompDbConfig(BaseModel):
    COMPDB_HOST: str = ""
    COMPDB_PORT: int = 1521
    COMPDB_USERNAME: str = ""
    COMPDB_PASSWORD: SecretStr = SecretStr("")
    COMPDB_SERVICE_NAME: str = ""
    COMPDB_NLS_LANG: str = ""


class GlobalConfig(BaseSettings):
    """Global configuration parameters."""

    model_config = SettingsConfigDict(secrets_dir="/etc/secrets")

    # CompDB Environment
    COMPDB_HOST: str = ""
    COMPDB_PORT: int = 1521
    COMPDB_USERNAME: str = ""
    COMPDB_PASSWORD: SecretStr = SecretStr("")
    COMPDB_SERVICE_NAME: str = ""
    COMPDB_NLS_LANG: str = ""


cnf = GlobalConfig().model_dump()
compdb = CompDbConfig(**cnf)
