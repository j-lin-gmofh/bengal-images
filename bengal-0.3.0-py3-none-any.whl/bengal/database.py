import os
import platform
from typing import Any, Dict, Type, Union

import oracledb
import pandas as pd
import sqlalchemy

from .settings import CompDbConfig, compdb


class DataSource:
    """Connect to data"""

    _instance: Union["DataSource", None] = None

    def __init__(self, compdb: CompDbConfig = compdb) -> None:
        self.host = compdb.COMPDB_HOST
        self.port = compdb.COMPDB_PORT
        self.username = compdb.COMPDB_USERNAME
        self.password = compdb.COMPDB_PASSWORD.get_secret_value()
        self.service_name = compdb.COMPDB_SERVICE_NAME

        ic_lib_dir = None
        if platform.system() == "Darwin" and platform.machine() == "x86_64":  # macOS
            ic_lib_dir = os.environ.get("HOME", "") + ("/Downloads/instantclient_19_8")

        oracledb.init_oracle_client(lib_dir=ic_lib_dir)

        connection_string = f"oracle+oracledb://{self.username}:{self.password}@{self.host}:{self.port}/?service_name={self.service_name}"
        self.engine = sqlalchemy.create_engine(connection_string)

    @classmethod
    def get_instance(cls: Type["DataSource"]) -> "DataSource":
        if not cls._instance:
            cls._instance = DataSource()
        return cls._instance


def query(
    query: str,
    con: Union[sqlalchemy.Engine, str] = DataSource(compdb).engine,
    **params: Dict[str, Any],
) -> pd.DataFrame:
    return pd.read_sql(query, con=con, params=params)
