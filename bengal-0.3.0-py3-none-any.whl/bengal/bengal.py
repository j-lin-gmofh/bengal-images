import datetime as dt
import getpass
import glob
import gzip
import os
import re
from configparser import ConfigParser
from math import floor
from typing import Any, Generator, Literal, TextIO

import numpy as np
import oracledb
import pandas as pd

db_username = ""

__encrypted_password = ""

DGCFD = "DGCFD"
DGFUN = "DGFUN"
DGFUNAEGIS = "DGFUNAEGIS"
DGFXOPAEGIS = "DGFXOPAEGIS"
DGFXOPR = "DGFXOPR"
DGGANN = "DGGANN"
DGGMOISCIF = "DGGMOISCIF"
DGGMOISDERI = "DGGMOISDERI"
DGGMOISLOGIN = "DGGMOISLOGIN"
DGGMOISSEC1 = "DGGMOISSEC1"
DGGMOISSEC2 = "DGGMOISSEC2"
DGSECCHART1 = "DGSECCHART1"
DGSECCHART2 = "DGSECCHART2"
DGSFX = "DGSFX"
DGTFX = "DGTFX"


def ditect_digit(commodity: str) -> Literal[3, 5]:
    commodity = commodity.replace("/", "")
    if commodity[3:6] == "JPY":
        return 3
    return 5


def is_odd(num: int) -> bool:
    n = num * 10
    while n < 1:
        n *= 10
    return n % 2 == 1


def calc_bidask(commodity: str, mid: int | float, sp: int) -> tuple[int, int]:
    digit = ditect_digit(commodity)
    mid = floor(mid * 10**digit) / 10**digit
    spread = sp / 10 ** (digit - 1)
    half = spread / 2

    if is_odd(sp):
        mid += 0.5 / 10 ** (digit)
    bid = round(mid - half, digit)
    ask = round(mid + half, digit)
    return bid, ask


def init_db_connection_conf(conf: Any, env: str) -> dict[str, Any]:
    compdb_type = ""
    if env == "prod":
        compdb_type = "compdb-prod"
    elif env == "stg":
        db_username = "COMPDB_DEBP_S1"
        compdb_type = "compdb-stg"
    else:
        raise Exception("connect(env) parameter must be either 'stg' or 'prod'")

    dsn = oracledb.makedsn(
        conf.get(compdb_type, "ip"),
        conf.get(compdb_type, "port"),
        conf.get(compdb_type, "sid"),
    )

    return {"username": db_username, "dsn": dsn}


def init_dsn(conf: Any, env: str) -> str:
    compdb_type = ""
    if env == "prod":
        compdb_type = "compdb-prod"
    elif env == "stg":
        # db_username = "COMPDB_DEBP_S1"
        compdb_type = "compdb-stg"
    else:
        raise Exception("connect(env) parameter must be either 'stg' or 'prod'")

    dsn = oracledb.makedsn(
        conf.get(compdb_type, "ip"),
        conf.get(compdb_type, "port"),
        conf.get(compdb_type, "sid"),
    )

    return dsn


def connect(env: str = "prod") -> Any:
    return connect_anondb(env)


def connect_compdb(env: str = "prod") -> Any:
    conf = ConfigParser()
    conf.read("/home/opt/jupyterhub/notebooks/shared/bengal_config.ini")
    connect_conf = init_db_connection_conf(conf, env)

    # encrypt_key = "hashimo-tosa-n"

    try:
        connection = oracledb.connect(
            get_username(), get_password(), connect_conf["dsn"]
        )
    except Exception as exc:
        __encrypted_password = ""
        raise exc

    return connection


def connect_anondb(env: str = "prod") -> Any:
    conf = ConfigParser()
    conf.read("/home/opt/jupyterhub/notebooks/shared/bengal_config_anondb.ini")
    connect_conf = init_db_connection_conf(conf, env)

    # encrypt_key = "hashimo-tosa-n"

    try:
        connection = oracledb.connect(
            get_username(), get_password(), connect_conf["dsn"]
        )
    except Exception as exc:
        __encrypted_password = ""
        raise exc

    return connection


def query_anondb_by_guid(table_name: str, id_list: list[Any]) -> pd.DataFrame:
    return query_anondb_with_tmp_join(table_name, "GLOBAL_USER_ID", id_list)


def query_anondb_by_prospectiveno(table_name: str, id_list: list[Any]) -> pd.DataFrame:
    return query_anondb_with_tmp_join(table_name, "PROSPECTIVE_NO", id_list)


def query_anondb_with_tmp_join(
    table_name: str, id_key: Any, id_list: list[Any]
) -> pd.DataFrame:
    # quick hack
    env_keys = ["BSDA_ANONDB_PW"]
    with open("/home/devgmo/.bashrc", encoding="utf-8") as f:
        for line in f:
            entry = line.replace("export ", "").strip().split("=")
            if entry[0] in env_keys:
                os.environ[entry[0]] = entry[1]

    conf = ConfigParser()
    conf.read("/home/opt/jupyterhub/notebooks/shared/bengal_config_anondb.ini")
    env = "prod"
    dsn = init_dsn(conf, env)

    connection = oracledb.connect("BSDA", os.environ.get("BSDA_ANONDB_PW"), dsn)
    del os.environ["BSDA_ANONDB_PW"]

    print("Trying to populate temporary table BSDA.TMP_ID_LIST_ON_TRANSACTION")
    for i in id_list:
        query_str = (
            "INSERT INTO BSDA.TMP_ID_LIST_ON_TRANSACTION (ID) values ('" + str(i) + "')"
        )
        connection.cursor().execute(query_str)
    print(
        "Inserted " + str(len(id_list)) + " records to BSDA.TMP_ID_LIST_ON_TRANSACTION"
    )

    print("Running query")
    query_str = f"""
            SELECT /*+ leading(tmp_tbl@BSDA.TMP_ID_LIST_ON_TRANSACTION data_tbl) use_hash(data_tbl) */ data_tbl.*
            FROM {table_name} data_tbl
            WHERE EXISTS (SELECT 1
                FROM BSDA.TMP_ID_LIST_ON_TRANSACTION tmp_tbl
                WHERE data_tbl.{id_key}  = tmp_tbl.ID)
            """
    print(query_str)

    return pd.read_sql(query_str, connection)


def get_ip_info(id_list: list[Any]) -> pd.DataFrame:
    # quick hack
    env_keys = ["COMPDB_PW"]
    with open("/home/devgmo/.bashrc") as f:
        for line in f:
            entry = line.replace("export ", "").strip().split("=")
            if entry[0] in env_keys:
                os.environ[entry[0]] = entry[1]

    conf = ConfigParser()
    conf.read("/home/opt/jupyterhub/notebooks/shared/bengal_config.ini")
    env = "prod"
    dsn = init_dsn(conf, env)
    print(dsn)
    connection = oracledb.connect("BSDA", os.environ.get("COMPDB_PW"), dsn)
    del os.environ["COMPDB_PW"]

    print("Trying to populate temporary table BSDA.TMP_ID_LIST_ON_TRANSACTION")
    for i in id_list:
        query_str = (
            "INSERT INTO BSDA.TMP_ID_LIST_ON_TRANSACTION (ID) values (inet_aton('"
            + str(i)
            + "'))"
        )
        connection.cursor().execute(query_str)
    print(
        "Inserted " + str(len(id_list)) + " records to BSDA.TMP_ID_LIST_ON_TRANSACTION"
    )

    print("Running query")
    query_str = r"""
            select /*+ leading(sr pc pr) no_swap_join_inputs(pr)
            index(pc (classb_addr ip_from ip_to))
            index_rs_asc(pr (country_code ip_from ip_to))
            batch_table_access_by_rowid(pr) use_nl(pc) use_hash(pr) */ inet_ntoa(sr.ID)
            as IP_ADDR , pr.country_code , pr.country_name , pr.region_name , pr.city_name ,
            pr.latitude||','||pr.longitude as LATITUDE_LONGITUDE , pr.isp as ISP , pr.domain , pr.mcc ,
            pr.mnc , pr.mobile_brand , pr.usage_type , inet_ntoa(pr.ip_from)||' - '||inet_ntoa(pr.ip_to)
            as IP_RANGE from BSDA.TMP_ID_LIST_ON_TRANSACTION sr inner join compdb.ip_geo_loc_classb pc on
            pc.classb_addr = regexp_substr(inet_ntoa(sr.ID), '\d+\.\d+.')
            inner join COMPDB.ip_geo_loc pr on pr.ip_from = pc.ip_from and pr.ip_to = pc.ip_to and
            pr.ip_from <= sr.ID and pr.ip_to >= sr.ID order by country_code desc,region_name,city_name
            """
    print(query_str)

    return pd.read_sql(query_str, connection)


def get_username() -> str:
    global db_username
    if db_username == "":
        if os.environ.get("COMPDB_PW") is not None:
            return "DEBP"
        base_notebook_dir = "/home/opt/jupyterhub/notebooks/"
        db_username = os.getcwd().replace(base_notebook_dir, "").split("/")[0]
        if db_username.startswith("shared"):
            print("You're at the shared directory, please tell me your username:")
            db_username = input()
    return db_username.replace("-", "_")


def get_password_comp() -> str:
    global __encrypted_password

    if __encrypted_password == "":
        if os.environ.get("COMPDB_PW") is not None:
            password = os.environ.get("COMPDB_PW")
        else:
            print("Input password")
            password = getpass.getpass()
        if password:
            __encrypted_password = password

    return __encrypted_password


def get_password() -> str:
    global __encrypted_password

    if __encrypted_password == "":
        if os.environ.get("TableauAnonPW") is not None:
            password = os.environ.get("TableauAnonPW")
        else:
            print("Input password")
            password = getpass.getpass()
        if password:
            __encrypted_password = password

    return __encrypted_password


def set_username(input_username: str) -> None:
    pass


def reset_username() -> None:
    set_username("")


def query(sql: str, **kw: Any) -> pd.DataFrame:
    if "env" not in kw:
        kw["env"] = "prod"
    if "params" not in kw:
        kw["params"] = None

    connection = connect(kw["env"])
    return pd.read_sql_query(sql, connection, params=kw["params"])


def query_compdb(sql: str, **kw: Any) -> pd.DataFrame:
    if "env" not in kw:
        kw["env"] = "prod"
    if "params" not in kw:
        kw["params"] = None

    connection = connect_compdb(kw["env"])
    return pd.read_sql_query(sql, connection, params=kw["params"])


def make_dir(path: str) -> None:
    if not os.path.exists(path):
        os.makedirs(path)


def read_ds_pickle() -> pd.DataFrame:
    """
    2019/11/5 k-kamataki
    At this moment, just read a pickle file described in
    http://confluence.gmo-sec.jp/display/BSD/DataScienceHUB
    """

    print(
        "Now loading /shared/20_DataScienceHUB/data/ver1/basic_data.pkl, expected to take 2 minutes"
    )
    path = "/home/opt/jupyterhub/notebooks/shared/20_DataScienceHUB/data/ver1/basic_data.pkl"
    return pd.read_pickle(path)


def parse_date(str_date: str) -> dt.datetime:
    """良く使う日付フォーマットをパースする努力をする"""
    if isinstance(str_date, (dt.date, dt.datetime)):
        return str_date

    date_formats = [
        "%Y%m%dT%H%M%S",
        "%Y/%m/%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y%m%d",
        "%Y-%m-%d",
        "%Y/%m/%d",
    ]
    for date_format in date_formats:
        try:
            return dt.datetime.strptime(str_date, date_format)
        except ValueError:
            pass

    raise ValueError("Invalid date format: {}".format(str_date))


def business_date_add(date: dt.date, amount: float | int) -> dt.date:
    count = 0
    target_date = date
    while count < abs(amount):
        yesterday = target_date + dt.timedelta(days=1 if amount > 0 else -1)
        target_date = yesterday
        if yesterday.month == 1 and yesterday.day == 1:
            continue
        if yesterday.weekday() <= 4:
            count += 1
    return target_date


def business_date_minus1(holiday_policy: int = 0) -> dt.date:
    """
    前営業日を返す。ただし、当日が土日の場合、holiday_policyに応じた補正を行う。
    ※NYCなどの時間の考慮は入っていない。

    holiday_policy: 1の時、土日だったら月曜を返す
    holiday_policy: 0の時、土日だったらそのまま土日を返す
    holiday_policy: -1の時、土日だったら金曜を返す
    """
    return business_date_add(business_date(holiday_policy), -1)


def business_date(holiday_policy: int = 0) -> dt.date:
    """
    当日を返す。ただし、当日が土日の場合、holiday_policyに応じた補正を行う。
    ※NYCなどの時間の考慮は入っていない。

    holiday_policy: 1の時、土日だったら月曜を返す
    holiday_policy: 0の時、土日だったらそのまま土日を返す
    holiday_policy: -1の時、土日だったら金曜を返す
    """
    today = dt.datetime.today().date()
    if holiday_policy > 0:
        return business_date_add(business_date_add(today, -1), 1)
    if holiday_policy == 0:
        return today
    if holiday_policy < 0:
        return business_date_add(business_date_add(today, 1), -1)
    return today


def qw(words: str) -> list[str | Any]:
    return re.split(r"\s+", words.strip())


def tables(condition: str | None = None, scheme: str = "COMPDB") -> pd.DataFrame:
    sql = """
    select
        TABLE_NAME,
        COMMENTS
    from
        all_tab_comments
    where owner=:scheme
        order by TABLE_NAME
    """
    df = query(sql, params={":scheme": scheme.upper()})
    if condition is not None:
        return df[df.TABLE_NAME.str.contains(condition)]
    else:
        return df


def table(table_name: str, scheme: str = "COMPDB") -> pd.DataFrame:
    sql = """
    select
        cc.COLUMN_NAME,
        cc.COMMENTS
    from
        all_col_comments cc
        inner join
        all_tab_columns c
        on (c.owner = cc.owner and c.table_name = cc.table_name and c.column_name = cc.column_name)
    where c.owner=:scheme
        and c.table_name = :table_name
    order by c.COLUMN_ID
    """
    return query(
        sql, params={":scheme": scheme.upper(), ":table_name": table_name.upper()}
    )


def sample_values(
    table_name: str, count: int = 100, scheme: str = "COMPDB"
) -> pd.DataFrame:
    sql = """
    select
        *
    from {0}.{1}
    where rownum <= :count
    order by 1 desc
    """
    return query(
        sql.format(scheme.lower(), table_name.upper()), params={":count": count}
    )


def read_fx_accesslog(file_pattern: str) -> Generator[dict[str, str], None, None]:
    for filepath in glob.glob(file_pattern):
        print(f"Reading from {filepath}")
        with open_file(filepath) as f:
            yield from process_file(f, filepath)


def open_file(filepath: str) -> TextIO:
    if filepath.endswith(".gz"):
        return gzip.open(filepath, "rt")
    return open(filepath, "rt", encoding="utf-8")


def process_file(file: TextIO, filepath: str) -> Generator[dict[str, str], None, None]:
    count = 0
    for line in file:
        count += 1
        print_progress(count)

        match = parse_line(line)
        if match:
            yield create_log_entry(match, filepath)


def print_progress(count: int) -> None:
    if count % 100000 == 0:
        if count > 0 and count % 1000000 == 0:
            print(f"+ {count}")
        else:
            print("-", end="")


def parse_line(line: str) -> re.Match[str] | None:
    pattern = r'^(.*?) - - \[(.*?) .*? "POST ([/\.\w]+) .*"([-/\.\,\(\)\w\s]+)" .*X-FNH=([-\w]+)" \[JSESSIONID=([-\w]+).*$'
    return re.match(pattern, line)


def create_log_entry(match: re.Match[str], filepath: str) -> dict[str, str]:
    return {
        "FILE_PATH": filepath,
        "IP": match.group(1),
        "DATETIME": match.group(2),
        "PATH": match.group(3),
        "UA": match.group(4),
        "HASH": match.group(5),
        "SESSION": match.group(6),
    }


def read_fx_journallog(file: str) -> Generator[dict[str, str | int], None, None]:
    for filepath in glob.glob(file):
        print(f"read from {file}")
        if filepath.endswith(".gz"):
            f = gzip.open(filepath, "rt")
        else:
            f = open(filepath, "rt")

        count = 0
        for line in f:
            if count % 100000 == 0:
                if count > 0 and count % 1000000 == 0:
                    print(f"+ {count}")
                else:
                    print("-", end="")

            count += 1
            # 2017-06-07 00:00:03,245 INFO  [JOURNAL.ROID] (default task-30) 1234567-28728289146983650-START-/neo/roid/tsukaPairList.do-{bnd=1,rqn=1496761201551}-[FXroidPlus/1.3.0(T-02D 4.1.2)]-[255.255.255.255]
            match = re.match(
                r"^(.*?) INFO.* (\d{7})-\d+-START-(.*?)-\{.*}-\[(.*?)\]-\[(.*?)\].*$",
                line,
            )
            # from IPython.core.debugger import Pdb; Pdb().set_trace()
            if match is None:
                continue
            yield {
                "FILE_PATH": filepath,
                "DATETIME": match.group(1),
                "GUID": int(match.group(2)),
                "PATH": match.group(3),
                "UA": match.group(4),
                "IP": match.group(5),
            }
        f.close()


def load_cfd_cppricelog(file: str) -> pd.DataFrame:
    dfs = []
    for filepath in glob.glob(file):
        print("read from " + filepath)
        if filepath.endswith(".gz"):
            f = gzip.open(filepath, "rt")
        else:
            f = open(filepath, "rt")

        dfs.append(
            pd.read_csv(
                f,
                names=[
                    "datetime",
                    "CPID",
                    "EXCHANGE",
                    "COMMODITY_CODE",
                    "MATURITY",
                    "hatena1",
                    "hatena2",
                    "BID_COUNT",
                    "BID1",
                    "BID1_QTY",
                    "BID2",
                    "BID2_QTY",
                    "BID3",
                    "BID3_QTY",
                    "BID4",
                    "BID4_QTY",
                    "BID5",
                    "BID5_QTY",
                    "BID6",
                    "BID6_QTY",
                    "BID7",
                    "BID7_QTY",
                    "BID8",
                    "BID8_QTY",
                    "BID9",
                    "BID9_QTY",
                    "BID10",
                    "BID10_QTY",
                    "BID_COUNT",
                    "ASK1",
                    "ASK1_QTY",
                    "ASK2",
                    "ASK2_QTY",
                    "ASK3",
                    "ASK3_QTY",
                    "ASK4",
                    "ASK4_QTY",
                    "ASK5",
                    "ASK5_QTY",
                    "ASK6",
                    "ASK6_QTY",
                    "ASK7",
                    "ASK7_QTY",
                    "ASK8",
                    "ASK8_QTY",
                    "ASK9",
                    "ASK9_QTY",
                    "ASK10",
                    "ASK10_QTY",
                    "LAST",
                ],
            )
        )
        f.close()
    df = pd.concat(dfs, axis=1)
    return df


def path_fileserver() -> str:
    return "/home/samba/fileserver/sec/deri"


def path_backupdisk() -> str:
    return "/home/samba/backup-disk1/deri"


def path_backupdisk_jupyterdata() -> str:
    return "/home/samba/backup-disk1/deri/jupyter-data"


def path_log_sfx() -> str:
    return path_log() + "/sfx"


def path_log_cfd() -> str:
    return path_log() + "/cfd"


def path_log_fxop() -> str:
    return path_log() + "/fxop"


def path_log() -> str:
    return "/home/samba/log"


def path_datafile() -> str | None:
    for i in ["Shared/", "./", "../", "../../", "../../../", "../../../../"]:
        if os.path.exists(i + "000_データファイル"):
            return i + "000_データファイル"
    return None


def userlist_from_guid(guid_list: int | list[int]) -> pd.DataFrame:
    """
    GUIDからユーザの一覧を取得する
    """
    sql = """
        select
            customer_cd,
            global_user_id
            from dgsfx.m_account
            where global_user_id in ({0})
            order by global_user_id
        """
    if isinstance(guid_list, int):
        guid_list = [guid_list]
    # con=にコネクション、index_colにDataFrameのインデックスに指定したいものを指定する
    df = query(sql.format(",".join("'" + str(x) + "'" for x in guid_list)))
    return df


def userlist_from_customercd(customer_cd_list: int | list[int]) -> pd.DataFrame:
    """
    口座番号からユーザの一覧を取得する
    """
    sql = """
        select
            customer_cd,
            global_user_id
            from dgsfx.m_account
            where customer_cd in ({0})
            order by global_user_id
        """
    if isinstance(customer_cd_list, int):
        customer_cd_list = [customer_cd_list]
    # con=にコネクション、index_colにDataFrameのインデックスに指定したいものを指定する
    df = query(sql.format(",".join("'" + str(x) + "'" for x in customer_cd_list)))
    return df


def userlist_from_acustomerno(acustomerno_list: list[int]) -> pd.DataFrame:
    """
    口座番号からユーザの一覧を取得する
    """
    sql = """
        select
            BUTEN_CODE || ACCOUNT_NUMBER as CUSTOMER_CD,
            global_user_id,
            ACUSTOMERNO
        from dgfxopr.OP_ACCOUNT
        where ACUSTOMERNO in ({0})
        """
    df = None
    for acustomerno_list in [
        acustomerno_list[x : x + 1000] for x in range(0, len(acustomerno_list), 1000)
    ]:
        if isinstance(acustomerno_list, int):
            acustomerno_list = [acustomerno_list]
        # con=にコネクション、index_colにDataFrameのインデックスに指定したいものを指定する
        tmp = query(sql.format(",".join("'" + str(x) + "'" for x in acustomerno_list)))
        if df is None:
            df = tmp
        else:
            df = df.append(tmp)
    return df


# def angola(guid_list):
#     """Angolaの分析を実行する
#
#     Keyword Arguments:
#     guid_list -- 実行対象となるGUIDのリスト
#     """
#     os.environ["RUNNING_ENV"] = "prod"
#     os.environ["ANGOLA_HOME"] = "/home/fxgmo/angola"
#     if os.environ["ANGOLA_HOME"] not in sys.path:
#         sys.path.append(os.environ["ANGOLA_HOME"])
#
#     from app.batch.analyze import analyze
#
#     a = analyze.Analyze(dt.datetime.now(), guid_list, "other")
#     a.execute()


def cfd_find_ticktable(business_date: Any) -> str:
    """COMPDBにあるCFDのティックテーブルから適切なテーブルを探し出す

    CFDの場合、直近のティックはCUSTOMER_PRICE_HISTORYに入ってくるが、古いデータはCUSTOMER_PRICE_H[YYYYMM]に退避されていく仕様

    Keyword Arguments:
        business_date -- 対象営業日
    """
    found = None
    for ym in tables("CUSTOMER_PRICE").TABLE_NAME.str.replace("CUSTOMER_PRICE_H", ""):
        if business_date[0:6] == ym:
            found = ym
    if found:
        return "CUSTOMER_PRICE_H{0}".format(found)
    else:
        return "CUSTOMER_PRICE_HISTORY"


def cfd_tickrate(product_code: Any, business_date: Any, limit: int = 0) -> pd.DataFrame:
    """ティックレート取得

    compdbのCUSTOMER_PRICE_HISTORY(H[YYYYMM])からティックデータを取得する
    CFDの場合、直近のティックはCUSTOMER_PRICE_HISTORYに入ってくるが、古いデータはCUSTOMER_PRICE_H[YYYYMM]に退避されていく仕様

    Keyword Arguments:
        product_code  -- 銘柄コード
        business_date -- 対象営業日
        limit         -- 取得データ件数
    """
    # target_table = cfd_find_ticktable(business_date)
    limit_condition = "where rownum < {0}".format(limit) if limit > 0 else ""
    df = query(
        """select
            *
            from
            (select
                *
                from comphist.CUSTOMER_PRICE_HISTORY
                where CFD_PRODUCT_CODE = :product_code
                and CREATE_BUSINESS_DATE = :business_date
                order by CREATE_DATETIME
            )
            {0}
            """.format(limit_condition),
        params={":product_code": product_code, ":business_date": business_date},
    )
    if df.size == 0:
        print("Not found data {0}".format(business_date))
    else:
        return df.set_index("CREATE_DATETIME")


def cfd_orderlist(product_code: Any, business_date: Any, guid: int = 0) -> pd.DataFrame:
    """CFDの成行注文の一覧を返す

    Keyword Arguments:
    product_code  -- 銘柄コード
    business_date -- 対象営業日
    guid          -- グローバルユーザID
    """

    guid_condition = "and o.GLOBAL_USER_ID = :guid" if guid > 0 else ""
    params = {":product_code": product_code, ":business_date": business_date}
    if guid > 0:
        params[":guid"] = guid
    df = query(
        """
        select
            o.GLOBAL_USER_ID,
            o.ORDER_PRICE,
            o.BUY_SELL_TYPE,
            o.SETTLE_TYPE,
            o.ORDER_DATETIME,
            o.ORDER_QUANTITY
        from compdb.CFD_ORDER o
            inner join
            compdb.cfd_product p
            on(o.CFD_PRODUCT_CODE = p.CFD_PRODUCT_CODE)
        where o.CFD_PRODUCT_CODE = :product_code
            and o.INVALID_BUSINESS_DATE = :business_date
            and o.EXECUTION_TYPE = 1
            and o.ORDER_TYPE = 1
            {0}
        order by ORDER_DATETIME
            """.format(guid_condition),
        params=params,
    ).set_index("ORDER_DATETIME")
    df.BUY_SELL_TYPE = pd.to_numeric(df.BUY_SELL_TYPE)
    df.SETTLE_TYPE = pd.to_numeric(df.SETTLE_TYPE)
    return df


def fx_business_timerange(commodity_cd: Any, business_date: Any) -> list[Any]:
    """営業日テーブルから開始と終了時間を取得する"""
    df = query(
        """
        select
            TRADE_START_TIMES,
            TRADE_END_TIMES
        from cpsfx.M_COMMODITY_CALENDAR
        where commodity_cd = :commodity_cd
        and business_date = :business_date
        """,
        params={":commodity_cd": commodity_cd, ":business_date": business_date},
    )
    if df.size == 0:
        return [None, None]
    else:
        return df.T[0].tolist()


def fx_tickrate(
    commodity_cd: Any,
    business_date: Any | None = None,
    start_time: Any | None = None,
    end_time: Any | None = None,
    band: int = 1,
    limit: int = 0,
    warikomi: bool = False,
) -> pd.DataFrame | None:
    """ティックレート取得

    SFXのI_PRICEからティックデータを取得する

    Keyword Arguments:
        commodity_cd  -- 通貨ペアコード
        business_date -- 対象営業日
        start_time    -- 開始日時
        end_time      -- 終了日時
        limit         -- 取得データ件数
    """
    if business_date is None and start_time is None and end_time is None:
        print("Must set to business_date or start_time, end_time")
        return None

    # 営業日テーブルから開始と終了時間を取得する
    if business_date is not None:
        bd_start_time, bd_end_time = fx_business_timerange(commodity_cd, business_date)

        if bd_start_time is None or bd_end_time is None:
            return None

        if start_time is None:
            start_time = bd_start_time
        if end_time is None:
            end_time = bd_end_time

    q = """
        select *
        from (
            select
            o.CREATE_TIME as DATETIME,
            o.MID,
            o.BID,
            o.ASK,
            o.VALID_FLG,
            o.HOOVER_PRICE_ID,
            NULL as WARIKOMI_FLG
        from DGSFX.I_PRICE_HCC o
            where o.CREATE_TIME between :start_time and :end_time
            and o.commodity_cd = :commodity_cd
            and o.band = :band
        order by o.CREATE_TIME
        )
        {0}
        """
    if warikomi:
        q = """select
            *
            from (
                select
                o.CREATE_TIME as DATETIME,
                o.MID,
                o.BID,
                o.ASK,
                o.VALID_FLG,
                o.HOOVER_PRICE_ID,
                o.WARIKOMIFLG as WARIKOMI_FLG
            from DGSFX.I_PRICE_WARIKOMI o
            where o.CREATE_TIME between :start_time and :end_time
                and o.commodity_cd = :commodity_cd
                and o.band = :band
            order by o.CREATE_TIME
            )
            {0}
        """
    limit_condition = "where rownum < {0}".format(limit) if limit > 0 else ""
    df = query(
        q.format(limit_condition),
        params={
            ":commodity_cd": commodity_cd,
            ":band": band,
            ":start_time": start_time,
            ":end_time": end_time,
        },
    )
    if df.size == 0:
        print("Not found data {0}".format(business_date))
        return None
    else:
        return df.set_index("DATETIME")


def fx_orderlist(commodity_cd: Any, business_date: Any, guid: int = 0) -> pd.DataFrame:
    """FXの成行注文の一覧を返す

    Keyword Arguments:
    commodity_cd  -- 通貨ペアコード
    business_date -- 対象営業日
    guid          -- グローバルユーザID
    """

    guid_condition = "and o.GLOBAL_USER_ID = :guid" if guid > 0 else ""
    params = {":commodity_cd": commodity_cd, ":business_date": business_date}
    if guid > 0:
        params[":guid"] = guid
    df = query(
        """
        select
            o.ORDER_NO as ORDER_NO,
            o.GLOBAL_USER_ID,
            o.ORDER_PRICE,
            o.BUY_SELL_TYPE,
            o.SETTLE_TYPE,
            o.ORDER_DATETIME,
            o.ORDER_QUANTITY
        from cpsfx.C_ORDER o
        where o.COMMODITY_CD = :commodity_cd
            and o.ORDER_DATE_NY = :business_date
            and o.EXECUTION_TYPE = 0
            and o.ORDER_TYPE = 0
            {0}
        order by ORDER_DATETIME
            """.format(guid_condition),
        params=params,
    ).set_index("ORDER_DATETIME")
    df.BUY_SELL_TYPE = pd.to_numeric(df.BUY_SELL_TYPE)
    df.SETTLE_TYPE = pd.to_numeric(df.SETTLE_TYPE)
    return df


# 非推奨 from fx import commodity　を使ってください
def fx_commodity_code(commodity_name: str | int) -> int | tuple[int, Any] | None:
    if isinstance(commodity_name, int):
        return commodity_name
    name = commodity_name.replace("/", "")
    products = fx_commodity()
    res = products[products.NAME == name].reset_index()
    if len(res) > 0:
        return int(res.ix[0].CODE), res.ix[0].NAME
    else:
        return None


# 非推奨 from fx import commodity　を使ってください
def fx_product(commodity_cd: int = 0) -> pd.DataFrame:
    return fx_commodity(commodity_cd)


# 非推奨 from fx import commodity　を使ってください
def fx_commodity(commodity_cd: int = 0) -> pd.DataFrame:
    """FXの通貨一覧を返す

    Keyword Arguments:
    commodity_cd -- COMMODITY_CD
    """
    commodity_condition = (
        "where COMMODITY_CD = :commodity_cd" if commodity_cd > 0 else ""
    )
    params = {}
    if commodity_cd > 0:
        params[":commodity_cd"] = commodity_cd
    df = query(
        """
            select
            COMMODITY_CD CODE,
            COMMODITY_NAME_E NAME,
            CONV_COMMODITY_CD CONVERSION,
            TRADE_UNIT,
            FLOATING_POS,
            INCREMENT_VALUE,
            DISPLAY_ORDER,
            MAX_ORDER_NARROW,
            MAX_ORDER_LARGE,
            MIN_ORDER_NARROW,
            MIN_ORDER_LARGE,
            COVER_ORDER_NARROW,
            COVER_ORDER_LARGE
            from cpsfx.m_commodity
    {0}""".format(commodity_condition),
        params=params,
    ).set_index("CODE")
    df.NAME = df.NAME.str.replace("/", "")
    return df


def cfd_product(product_cd: str | int = "", type: int = 0) -> pd.DataFrame:
    """CFDの銘柄一覧を返す

    ※各限月の銘柄は普段使わないのでここでは返さない。
    TODO 必要になったら考える

    Keyword Arguments:
    product_cd -- 指定したCFD_PRODUCT_CODEの銘柄のみ返す
    type       -- 商品の区分で絞り込んで返す
    """
    product_condition = ""
    type_condition = ""

    params = {}
    if product_cd != "":
        params[":product_cd"] = product_cd
        product_condition = "and CFD_PRODUCT_CODE = :product_cd"
    if type > 0:
        params[":type"] = type
        type_condition = "and product_type = :type"

    df = query(
        """
        select
            CFD_PRODUCT_CODE CODE,
            MEIGARA_SEI_KANJI NAME,
            TRADE_UNIT,
            PRODUCT_TYPE TYPE,
            CURRENCY
        from compdb.cfd_product
        where product_type in(5,6,7,8,9,10,12,13,14)
        {0}
        {1}
        order by TYPE, CODE
        """.format(product_condition, type_condition),
        params=params,
    ).set_index("CODE")
    return df


def construct_id_in_union_all_query(base_query: str, id_list: list[int]) -> str:
    factor_1000 = np.ceil((len(id_list) / 1000))
    splitted_id_list = np.array_split(id_list, factor_1000)

    query_list = []
    for tmp_id_list in splitted_id_list:
        ids_str = (",").join([str(tmp_id) for tmp_id in tmp_id_list])
        tmp_query = base_query.format(ids_str)
        query_list.append(tmp_query)

    return " UNION ALL ".join(query_list)


def get_first_login(guid_list: list[int]) -> pd.DataFrame:
    guid_list_s = ",".join([str(i) for i in guid_list])

    env_keys = [
        "COMPDB_PW",
        "RUNNING_ENV",
        "LD_LIBRARY_PATH",
        "ORACLE_HOME",
        "LC_CTYPE",
        "NLS_LANG",
    ]
    with open("/home/fxgmo/.bashrc") as f:
        for line in f:
            entry = line.replace("export ", "").strip().split("=")
            if entry[0] in env_keys:
                os.environ[entry[0]] = entry[1]
    DEBP_DATABASE_PASSWORD = os.environ["COMPDB_PW"]
    ORACLE_DATABASE_URI = "DEBP/" + DEBP_DATABASE_PASSWORD + "@10.50.1.55:1521/COMPDB"

    conn = oracledb.connect(ORACLE_DATABASE_URI)

    query_sso_login = """
        SELECT DISTINCT GLOBAL_USER_ID,
        FIRST_VALUE(LOGIN_DATETIME)
        OVER( partition by GLOBAL_USER_ID order by LOGIN_DATETIME ) as SSO_FIRST_LOGIN_DATETIME
        FROM COMPDB.SSO_LOGIN_HISTORY
        WHERE GLOBAL_USER_ID IN({0})
        AND OPERATOR_ID IS NULL
        AND LOGIN_KBN = 1
        GROUP BY GLOBAL_USER_ID, LOGIN_DATETIME
        """.format(guid_list_s)
    df_sso_login = pd.read_sql(query_sso_login, con=conn)

    query_uniqueid = """
        SELECT DISTINCT GLOBAL_USER_ID,
        FIRST_VALUE(UID_LOGIN_FIRST_DATE)
        OVER( partition by GLOBAL_USER_ID order by UID_LOGIN_FIRST_DATE ) as UID_FIRST_LOGIN_DATETIME
        FROM COMPDB.UNIQUE_ID_MANAGEMENT
        WHERE GLOBAL_USER_ID IN({0})
        AND ACTIVE_FLAG = 1
        GROUP BY GLOBAL_USER_ID, UID_LOGIN_FIRST_DATE
        """.format(guid_list_s)
    df_uniqueid_login = pd.read_sql(query_uniqueid, con=conn)
    df = pd.merge(df_sso_login, df_uniqueid_login, on="GLOBAL_USER_ID")

    df = df.assign(
        OLDEST_LOGIN_TIME=df.apply(
            lambda row: min(row.SSO_FIRST_LOGIN_DATETIME, row.UID_FIRST_LOGIN_DATETIME),
            axis=1,
        )
    )

    return df


def get_account_kisei_info(
    guid_list: list[int],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    guid_list_s = ",".join([str(i) for i in guid_list])

    env_keys = [
        "COMPDB_PW",
        "RUNNING_ENV",
        "LD_LIBRARY_PATH",
        "ORACLE_HOME",
        "LC_CTYPE",
        "NLS_LANG",
    ]
    with open("/home/fxgmo/.bashrc") as f:
        for line in f:
            entry = line.replace("export ", "").strip().split("=")
            if entry[0] in env_keys:
                os.environ[entry[0]] = entry[1]
    DEBP_DATABASE_PASSWORD = os.environ["COMPDB_PW"]
    ORACLE_DATABASE_URI = "DEBP/" + DEBP_DATABASE_PASSWORD + "@10.50.1.55:1521/COMPDB"

    conn = oracledb.connect(ORACLE_DATABASE_URI)

    query_stock_account = """
        SELECT GLOBAL_USER_ID, FXOP_KISEI_SHINKI, FXOP_FURIKAE_KISEI,
            UPDATE_DATE, UPDATE_PERSON
        FROM COMPDB.STOCK_ACCOUNT
        WHERE GLOBAL_USER_ID IN({0})
        AND ACTIVE_FLAG = 1
        """.format(guid_list_s)
    df_query_stock_account = pd.read_sql(query_stock_account, con=conn)
    df_query_stock_account.sort_values(
        by="GLOBAL_USER_ID", ascending=True, inplace=True
    )

    query_stock_account_kisei_history = """
        SELECT GLOBAL_USER_ID, FXOP_KISEI_SHINKI,
            INPUT_DATE, INPUT_PERSON, UPDATE_DATE, UPDATE_PERSON
        FROM COMPDB.STOCK_ACCOUNT_KISEI_HISTORY
        WHERE GLOBAL_USER_ID IN({0})
            AND ACTIVE_FLAG = 1
        """.format(guid_list_s)
    df_stock_account_kisei_history = pd.read_sql(
        query_stock_account_kisei_history, con=conn
    )
    df_stock_account_kisei_history.sort_values(
        by=["GLOBAL_USER_ID", "UPDATE_DATE", "INPUT_DATE"],
        ascending=[True, True, True],
        inplace=True,
    )

    query_trade_kisei_control = """
        SELECT GLOBAL_USER_ID, TRADE_KISEI_KBN, KISEI_ENFORCE_DATETIME, UPDATE_PERSON
        FROM DGGMOISCIF.TRADE_KISEI_CONTROL
        WHERE GLOBAL_USER_ID IN({0})
            AND ACTIVE_FLAG = 1
        """.format(guid_list_s)
    df_trade_kisei_control = pd.read_sql(query_trade_kisei_control, con=conn)

    query_trade_kisei_kbn = """
        SELECT TRADE_KISEI_KBN, TRADE_KISEI_NAME
        FROM COMPDB.TRADE_KISEI_KBN_TBL
        WHERE ACTIVE_FLAG = 1
        """
    df_trade_kisei_kbn = pd.read_sql(query_trade_kisei_kbn, con=conn)

    df_trade_kisei = pd.merge(
        df_trade_kisei_control, df_trade_kisei_kbn, on="TRADE_KISEI_KBN"
    )
    df_trade_kisei.sort_values(
        by=["GLOBAL_USER_ID", "KISEI_ENFORCE_DATETIME"],
        ascending=[True, True],
        inplace=True,
    )

    return df_query_stock_account, df_stock_account_kisei_history, df_trade_kisei


def get_fxop_kisei_accounts() -> pd.DataFrame:
    env_keys = [
        "COMPDB_PW",
        "RUNNING_ENV",
        "LD_LIBRARY_PATH",
        "ORACLE_HOME",
        "LC_CTYPE",
        "NLS_LANG",
    ]
    with open("/home/fxgmo/.bashrc") as f:
        for line in f:
            entry = line.replace("export ", "").strip().split("=")
            if entry[0] in env_keys:
                os.environ[entry[0]] = entry[1]
    DEBP_DATABASE_PASSWORD = os.environ["COMPDB_PW"]
    ORACLE_DATABASE_URI = "DEBP/" + DEBP_DATABASE_PASSWORD + "@10.50.1.55:1521/COMPDB"

    conn = oracledb.connect(ORACLE_DATABASE_URI)

    query_fxop_kisei_account = """
        SELECT *
        FROM COMPDB.TRADE_KISEI_CONTROL
        WHERE TRADE_KISEI_KBN IN (509, 511)
        AND ACTIVE_FLAG = 1
        """
    df_fxop_kisei_account = pd.read_sql(query_fxop_kisei_account, con=conn)
    return df_fxop_kisei_account
