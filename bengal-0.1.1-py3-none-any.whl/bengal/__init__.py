"""
    bengal package from b{p,s}-analyze{1,2}
"""

# should follow Semantic Versioning
# https://semver.org/
__version__ = '0.1.1'
